package edu.co225.lab5;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Array ar = new Array();

        ar.add(10);
        ar.add(11);
        ar.add(12);
        ar.add(13);
        ar.add(14);
        ar.add(15);
        ar.add(16);
        ar.add(17);
        ar.add(18);
        ar.add(19);
        ar.add(20);
        ar.add(21);
        ar.add(22);

        System.out.println(ar);


        System.out.println(ar.get(5));

        ar.remove(5);

        System.out.println(ar);

        ar.add(5,100);

        System.out.println(ar);

        ar.replace(6, 150);
        //ar.replace(120, 150);

        System.out.println(ar);

        ar.clear();
        System.out.println(ar);

        ar.add(10);
        ar.add(11);
        ar.add(12);
        ar.add(13);
        ar.add(14);

        System.out.println(ar);

    }
}
